ORNET Interior @ Furniture website
--------------------------------
Open index.html in a browser to preview the site.

Included:
- index.html
- style.css
- script.js
- ornet-logo.png
- projects/ (5 supplied project photos)

The Projects section now uses the supplied photos:
1. Cafe Interior
2. Bedroom Interior
3. Ceiling Design
4. Lighting & Decor
5. Wall Finish

To publish, upload the complete folder contents while preserving the projects/ folder.
